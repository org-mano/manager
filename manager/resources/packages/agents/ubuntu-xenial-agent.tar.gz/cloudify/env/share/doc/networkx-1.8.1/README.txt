NetworkX

NetworkX is a Python package for the creation, manipulation, and
study of the structure, dynamics, and functions of complex networks.  

Copyright (C) 2004-2013 NetworkX Developers
Aric Hagberg <hagberg@lanl.gov>
Dan Schult <dschult@colgate.edu>
Pieter Swart <swart@lanl.gov>

Distributed with a BSD license; see LICENSE.txt.

See http://networkx.lanl.gov/ for more information.
